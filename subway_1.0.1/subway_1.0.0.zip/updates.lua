Updates = {}

Updates.init = function()
	global.update_version = 1
end

Updates.run = function()
	if global.update_version < 1 then

	end
	global.update_version = 1
end
