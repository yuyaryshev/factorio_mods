data:extend(
{
    {
    type = "recipe",
    name = "blueprint",
    energy_required = 1,
    ingredients =
    {
      {"electronic-circuit", 20}
    },
    result = "blueprint",
    enabled = true
  },
  {
    type = "recipe",
    name = "deconstruction-planner",
    energy_required = 1,
    ingredients =
    {
      {"electronic-circuit", 20}
    },
    result = "deconstruction-planner",
    enabled = true
  }
})