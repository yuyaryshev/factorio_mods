require("prototypes.recipe")

data:extend({
	{
    type = "custom-input",
    name = "bluebuild-autobuild",
    key_sequence = "b",
    consuming = "none"
  },{
    type = "custom-input",
    name = "bluebuild-autodemo",
    key_sequence = "n",
    consuming = "none"
  }
 })