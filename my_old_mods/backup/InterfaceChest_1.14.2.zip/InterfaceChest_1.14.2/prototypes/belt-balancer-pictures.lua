  ----------------------  BELT Balancer 
		belt_balancer_horizontal =
		  {
			filename = "__InterfaceChest__/graphics/belt-balancer.png",
			priority = "extra-high",
			width = 40,
			height = 40,
			frame_count = 32
		  }
		belt_balancer_vertical =
		  {
			filename = "__InterfaceChest__/graphics/belt-balancer.png",
			priority = "extra-high",
			width = 40,
			height = 40,
			frame_count = 32,
			y = 40,
		  }
		belt_balancer_ending_top =
		  {
			filename = "__InterfaceChest__/graphics/belt-balancer.png",
			priority = "extra-high",
			width = 40,
			height = 40,
			frame_count = 32,
			y = 80
		  }
		belt_balancer_ending_bottom =
		  {
			filename = "__InterfaceChest__/graphics/belt-balancer.png",
			priority = "extra-high",
			width = 40,
			height = 40,
			frame_count = 32,
			y = 120
		  }
		belt_balancer_ending_side =
		  {
			filename = "__InterfaceChest__/graphics/belt-balancer.png",
			priority = "extra-high",
			width = 40,
			height = 40,
			frame_count = 32,
			y = 160
		  }
		belt_balancer_starting_top =
		  {
			filename = "__InterfaceChest__/graphics/belt-balancer.png",
			priority = "extra-high",
			width = 40,
			height = 40,
			frame_count = 32,
			y = 200
		  }
		belt_balancer_starting_bottom =
		  {
			filename = "__InterfaceChest__/graphics/belt-balancer.png",
			priority = "extra-high",
			width = 40,
			height = 40,
			frame_count = 32,
			y = 240
		  }
		belt_balancer_starting_side =
		  {
			filename = "__InterfaceChest__/graphics/belt-balancer.png",
			priority = "extra-high",
			width = 40,
			height = 40,
			frame_count = 32,
			y = 280
		  }