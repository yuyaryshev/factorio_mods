MOD_NAME = "LogisticTrainNetwork"

require ("lib")
require ("config")
require ("prototypes.technology")
require ("prototypes.recipes")
require ("prototypes.items")
require ("prototypes.entities")
require ("prototypes.signals")
