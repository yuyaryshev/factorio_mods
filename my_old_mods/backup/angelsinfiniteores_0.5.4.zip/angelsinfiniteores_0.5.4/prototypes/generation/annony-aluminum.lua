if not angelsmods.ores.enablersomode then
data:extend(
{
	{
	type = "autoplace-control",
	name = "infinite-aluminum-ore",
	richness = true,
	order = "b-e"
	},
	{
	type = "noise-layer",
	name = "infinite-aluminum-ore"
	},
	{
	type = "resource",
	name = "infinite-aluminum-ore",
	icons =
		  {
			{
				icon = "__AnonyMods__/graphics/icons/resources/resource-2.png",
				tint = resource_color,
			},			
		  },
	flags = {"placeable-neutral"},
	order="a-b-a",
	tint = {r = 0.9, g = 0.64, b = 0.38},
	map_color = {r = 0.9, g = 0.64, b = 0.38},
	infinite=true,
	minimum=300,
	normal=1500,
	maximum=6000,
    minable =
    {
      hardness = 1.1,
      mining_particle = "aluminum-particle",
      mining_time = 2,
      results = CheckResultsMining( 
		  { 
			{ name = "aluminum_ore", type = "item", mineprobability = Config.Number["bauxite-probability"] },
			{ name = "hematite", type = "item", mineprobability = Config.Number["hematite-aluminum-probability"] },
		  },
		  
		  { name = "iron-ore", type = "item", mineprobability = 1 } 
	  
	  )
    },
	collision_box = {{ -0.1, -0.1}, {0.1, 0.1}},
	selection_box = {{ -0.5, -0.5}, {0.5, 0.5}},
	autoplace =
	{
		control = "infinite-aluminum-ore",
		sharpness = 1,
		richness_multiplier = 5000,
		richness_multiplier_distance_bonus = 20,
		richness_base = 2000,
		coverage = 0.01,
		peaks = {
			{
				noise_layer = "infinite-aluminum-ore",
				noise_octaves_difference = -2.5,
				noise_persistence = 0.3,
				starting_area_weight_optimal = 0,
				starting_area_weight_range = 0,
				starting_area_weight_max_range = 2,
			},
			{
				noise_layer = "infinite-aluminum-ore",
				noise_octaves_difference = -2,
				noise_persistence = 0.3,
				starting_area_weight_optimal = 1,
				starting_area_weight_range = 0,
				starting_area_weight_max_range = 2,
			},
			{
				influence = 0.15,
				starting_area_weight_optimal = 0,
				starting_area_weight_range = 0,
				starting_area_weight_max_range = 2,
			}
		}
	},
	stage_counts = {1},
	stages =
	{
	  sheet =
	  {
		filename = "__angelsinfiniteores__/graphics/entity/ores-inf/ore-3-inf.png",
		priority = "extra-high",
		tint = {r=0.777, g=0.7, b=0.333},
		width = 38,
		height = 38,
		frame_count = 8,
		variation_count = 1
	  }
	},
  },
}
)
else
data:extend(
{
  {
	type = "resource",
	name = "infinite-aluminum-ore",
	icon = "__bobores__/graphics/icons/aluminum-ore.png",
	flags = {"placeable-neutral"},
	order="a-b-a",
	tint = {r=0.777, g=0.7, b=0.333},
	map_color = {r=0.777, g=0.7, b=0.333},
	infinite=true,
	minimum=300,
	normal=1500,
	maximum=6000,
	minable =
	{
	  hardness = 1.4,
	  mining_particle = "aluminum-particle",
	  mining_time = 2,
	  result = "aluminum-ore"
	},
	collision_box = {{ -0.1, -0.1}, {0.1, 0.1}},
	selection_box = {{ -0.5, -0.5}, {0.5, 0.5}},
	stage_counts = {1},
	stages =
	{
	  sheet =
	  {
		filename = "__angelsinfiniteores__/graphics/entity/ores-inf/ore-3-inf.png",
		priority = "extra-high",
		tint = {r=0.777, g=0.7, b=0.333},
		width = 38,
		height = 38,
		frame_count = 8,
		variation_count = 1
	  }
	},
  },
}
)
end
