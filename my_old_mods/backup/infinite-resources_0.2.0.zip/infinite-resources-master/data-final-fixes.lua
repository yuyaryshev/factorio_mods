for k, v in pairs(data.raw.resource) do
	if not v.infinite then
		v.infinite = true
		v.minimum  = 175
		v.normal   = 350
	end
end

