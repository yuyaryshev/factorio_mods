# infinite-resources
A mod for factorio that modifies all non-infinite ores to have infinite yields.
Download the most recent version at https://mods.factorio.com/mods/smmalis37/infinite-resources.
