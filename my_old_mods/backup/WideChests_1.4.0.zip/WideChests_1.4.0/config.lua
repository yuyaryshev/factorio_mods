--There is hard limit of 42
MergingChests.MaxSize = 42

--What chest sizes should have recipes (for blueprint use)
--example: MergingChests.ChestRecipes = { 6, 12, 28, 40 }
MergingChests.ChestRecipes = { }