data:extend{
  {
    type = "recipe",
    name = "assembling-machine-dynamic",
    enabled = false,
    ingredients =
    {
      {"assembling-machine-2", 1},
      {"electronic-circuit", 10},
    },
    result="assembling-machine-dynamic",
  },
  {
    type = "recipe",
    name = "assembling-machine-dynamic-2",
    enabled = false,
    ingredients =
    {
      {"assembling-machine-3", 1},
      {"electronic-circuit", 10},
    },
    result="assembling-machine-dynamic-2",
  },
  {
    type = "recipe",
    name = "chemical-plant-dynamic",
    enabled = false,
    ingredients =
    {
      {"chemical-plant", 1},
      {"electronic-circuit", 10},
    },
    result="chemical-plant-dynamic",
  },
}
